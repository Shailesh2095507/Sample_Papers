package com.cognizant.shopping_cart.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.shopping_cart.model.Order;

public interface OrderRepository extends JpaRepository<Order, Integer>{
	
	

}
