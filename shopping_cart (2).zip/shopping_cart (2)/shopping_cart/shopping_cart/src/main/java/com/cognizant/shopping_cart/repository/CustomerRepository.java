package com.cognizant.shopping_cart.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.shopping_cart.model.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {

}
