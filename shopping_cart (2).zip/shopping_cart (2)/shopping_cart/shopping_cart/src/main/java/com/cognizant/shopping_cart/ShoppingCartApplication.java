package com.cognizant.shopping_cart;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cognizant.shopping_cart.model.Brand;
import com.cognizant.shopping_cart.model.Customer;
import com.cognizant.shopping_cart.model.Product;
import com.cognizant.shopping_cart.repository.BrandRepository;
import com.cognizant.shopping_cart.repository.CustomerRepository;
import com.cognizant.shopping_cart.repository.ProductRepository;

@SpringBootApplication
public class ShoppingCartApplication implements CommandLineRunner {
	
   private Logger logger = LoggerFactory.getLogger(this.getClass());
    
	
	@Autowired
	BrandRepository brandRepo;
	
	@Autowired
	ProductRepository productRepo;
	
	@Autowired
	CustomerRepository customerRepo;
	

	public static void main(String[] args) {
		SpringApplication.run(ShoppingCartApplication.class, args);
		
		
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		Brand brand1 = new Brand(20001, "IQOO", "YES");
		brandRepo.save(brand1);
		Brand brand2 = new Brand(20002, "Samsung", "YES");
		brandRepo.save(brand2);
		Brand brand3 = new Brand(20003, "Apple", "NO");
		brandRepo.save(brand3);
		Brand brand4 = new Brand(20004, "Vivo", "YES");
		brandRepo.save(brand4);
		
		Product product1 = new Product(10001, "IQOO3", 37990, 5, brandRepo.getById(20001));
		productRepo.save(product1);
		Product product2 = new Product(10002, "IQOOZ6", 41990, 4, brandRepo.getById(20001));
		productRepo.save(product2);
		Product product3 = new Product(10003, "Galaxy F12", 11499, 3, brandRepo.getById(20002));
		productRepo.save(product3);
		Product product4 = new Product(10004, "T1", 15999, 2, brandRepo.getById(20004));
		productRepo.save(product4);
		Product product5 = new Product(10005, "Y53s", 18499, 10, brandRepo.getById(20004));
		productRepo.save(product5);
		Product product6 = new Product(10006, "Galaxy M12", 13499, 2, brandRepo.getById(20002));
		productRepo.save(product6);
		Product product7 = new Product(10007, "IQOO7", 35999, 5, brandRepo.getById(20001));
		productRepo.save(product7);
		
		Customer customer1 = new Customer(30001, "Aditya", "Aditya_123");
		customerRepo.save(customer1);
		Customer customer2 = new Customer(30002, "Akash", "Akash_123");
		customerRepo.save(customer2);
		Customer customer3 = new Customer(30003, "Puja", "Puja_123");
		customerRepo.save(customer3);

		logger.info("All brand -> {} ", brandRepo.findAll());
		}
	
	

}
