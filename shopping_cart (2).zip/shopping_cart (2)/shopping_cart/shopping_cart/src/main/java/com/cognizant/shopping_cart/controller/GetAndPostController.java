package com.cognizant.shopping_cart.controller;

import java.util.Calendar;
import java.util.Date;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.shopping_cart.model.Customer;
import com.cognizant.shopping_cart.model.Order;
import com.cognizant.shopping_cart.model.Product;
import com.cognizant.shopping_cart.repository.CustomerRepository;
import com.cognizant.shopping_cart.repository.OrderRepository;
import com.cognizant.shopping_cart.repository.ProductRepository;

@RestController
public class GetAndPostController {
	
	@Autowired
	private ProductRepository productDao;
	
	@Autowired
	private OrderRepository orderDao;
	
	@Autowired
	private CustomerRepository customerDao;
	
	
	@GetMapping("/product/v1/get/info")
	public List<Product> retrieveProducts(){
		return productDao.findAll();
	}
	
	
	@PostMapping("/customer/{customerId}/product/{productId}/order/submit")
	public Order addOrder(@RequestBody Order newOrder, @PathVariable int customerId, @PathVariable int productId){
		
		Customer customer = customerDao.getById(customerId);
		newOrder.setCustomer(customer);
		
		Product product = productDao.getById(productId);
		newOrder.setProduct(product);
		
		Date date = new Date();
		newOrder.setOrderPlacedDt(date);
		Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.DATE, 1); 
        Date dateDispatch = c.getTime();
        newOrder.setOrderDispatcherDt(dateDispatch);
        Calendar del = Calendar.getInstance();
        del.setTime(date);
        del.add(Calendar.DATE, 7); 
        Date dateDelivery = del.getTime();
        newOrder.setOrderDeliveredDt(dateDelivery);

		
		System.out.println("--------->"+newOrder);
		Order order = orderDao.save(newOrder);
		
		//URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("{orderId}").buildAndExpand(order.getOrderId()).toUri();
		
	    return order;
	}
	
	

}
