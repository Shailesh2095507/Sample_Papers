package com.cognizant.shopping_cart.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.shopping_cart.model.Brand;

public interface BrandRepository extends JpaRepository<Brand, Integer>{
	
	
}
