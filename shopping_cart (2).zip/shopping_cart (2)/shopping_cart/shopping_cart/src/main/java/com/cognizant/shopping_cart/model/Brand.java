package com.cognizant.shopping_cart.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Entity
@Getter
@Setter
public class Brand {
	
	@Id
	private int brandId;
	
	private String brandName;
	private String brandActiveStatus;
	
	public Brand() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Brand(String brandName, String brandActiveStatus) {
		super();
		this.brandName = brandName;
		this.brandActiveStatus = brandActiveStatus;
	}
	public Brand(int brandId, String brandName, String brandActiveStatus) {
		super();
		this.brandId = brandId;
		this.brandName = brandName;
		this.brandActiveStatus = brandActiveStatus;
	}
	
	
	
	public int getBrandId() {
		return brandId;
	}
	public void setBrandId(int brandId) {
		this.brandId = brandId;
	}
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public String getBrandActiveStatus() {
		return brandActiveStatus;
	}
	public void setBrandActiveStatus(String brandActiveStatus) {
		this.brandActiveStatus = brandActiveStatus;
	}
	@Override
	public String toString() {
		return "Brand [brandId=" + brandId + ", brandName=" + brandName + ", brandActiveStatus=" + brandActiveStatus
				+ "]";
	}
	
	
	
	
}
