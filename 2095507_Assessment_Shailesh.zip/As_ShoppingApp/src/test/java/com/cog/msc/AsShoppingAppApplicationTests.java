package com.cog.msc;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cog.msc.entity.Product;
import com.cog.msc.repository.ProductRepo;

import com.cog.msc.entity.Order;
import com.cog.msc.repository.OrderRepo;
//import com.cog.msc.service.MainService;

@SpringBootTest
class AsShoppingAppApplicationTests 
{
	
		@Autowired
		ProductRepo productRepoTest;
		
		@Autowired
		OrderRepo orderRepoTest;

		@Test
		public void testReadAllProducts()
		{
			List<Product> list = productRepoTest.findAll();
			assertThat(list).size().isGreaterThan(0);
		}
		
		@Test
		public void testSingleProduct() 
		{
			Product product = productRepoTest.findById(21).get();
			assertEquals(2999.00, product.getPrice());
		}
		
		@Test
		public void testIfOrdersAvailable()
		{
			List<Order> list = orderRepoTest.findAll();
			assertThat(list).size().isGreaterThan(0);
		}
}