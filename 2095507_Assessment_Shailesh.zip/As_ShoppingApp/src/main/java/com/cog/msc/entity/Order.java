package com.cog.msc.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@JsonIgnoreProperties({"hibernateLazyInitializer"})
@Data
@Entity
@Table(name="Order_Data")
public class Order 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int orderId;
	
	private Date orderPlacedDt;
	private Date orderDispatcherDt;
	private Date orderDeliveredDt;
	private String orderStatus;
	
	@ManyToOne
	private Customer customer;
	
	@ManyToOne
	private Product  product;
	
	private String paymentSource;
	private String paymentStatus;
	private int quantity;
	
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Order(int orderId, Date orderPlacedDt, Date orderDispatcherDt, Date orderDeliveredDt, String orderStatus,
			Customer customer, Product product, String paymentSource, String paymentStatus, int quantity) {
		super();
		this.orderId = orderId;
		this.orderPlacedDt = orderPlacedDt;
		this.orderDispatcherDt = orderDispatcherDt;
		this.orderDeliveredDt = orderDeliveredDt;
		this.orderStatus = orderStatus;
		this.customer = customer;
		this.product = product;
		this.paymentSource = paymentSource;
		this.paymentStatus = paymentStatus;
		this.quantity = quantity;
	}

	public Order(String orderStatus, Customer customer, Product product, String paymentSource, String paymentStatus,
			int quantity) {
		super();
		this.orderStatus = orderStatus;
		this.customer = customer;
		this.product = product;
		this.paymentSource = paymentSource;
		this.paymentStatus = paymentStatus;
		this.quantity = quantity;
	}

	public Order(String orderStatus, String paymentSource, String paymentStatus, int quantity) {
		super();
		this.orderStatus = orderStatus;
		this.paymentSource = paymentSource;
		this.paymentStatus = paymentStatus;
		this.quantity = quantity;
	}

	
	
	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public Date getOrderPlacedDt() {
		return orderPlacedDt;
	}

	public void setOrderPlacedDt(Date orderPlacedDt) {
		this.orderPlacedDt = orderPlacedDt;
	}

	public Date getOrderDispatcherDt() {
		return orderDispatcherDt;
	}

	public void setOrderDispatcherDt(Date orderDispatcherDt) {
		this.orderDispatcherDt = orderDispatcherDt;
	}

	public Date getOrderDeliveredDt() {
		return orderDeliveredDt;
	}

	public void setOrderDeliveredDt(Date orderDeliveredDt) {
		this.orderDeliveredDt = orderDeliveredDt;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public String getPaymentSource() {
		return paymentSource;
	}

	public void setPaymentSource(String paymentSource) {
		this.paymentSource = paymentSource;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", orderPlacedDt=" + orderPlacedDt + ", orderDispatcherDt="
				+ orderDispatcherDt + ", orderDeliveredDt=" + orderDeliveredDt + ", orderStatus=" + orderStatus
				+ ", customer=" + customer + ", product=" + product + ", paymentSource=" + paymentSource
				+ ", paymentStatus=" + paymentStatus + ", quantity=" + quantity + "]";
	}
	
}
