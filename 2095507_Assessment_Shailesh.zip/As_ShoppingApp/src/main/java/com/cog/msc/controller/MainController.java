package com.cog.msc.controller;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cog.msc.entity.Customer;
import com.cog.msc.entity.Order;
import com.cog.msc.entity.Product;
import com.cog.msc.repository.CustomerRepo;
import com.cog.msc.repository.OrderRepo;
import com.cog.msc.repository.ProductRepo;

@RestController
public class MainController 
{
	@Autowired
	private ProductRepo proRepo;

	@Autowired
	private OrderRepo ordRepo;
	
	@Autowired
	private CustomerRepo custRepo; 
	
	@GetMapping("/product/get/details")
	public List<Product> getAllProducts()
	{
		return proRepo.findAll();
	}
	
	@PostMapping("/customer/{customerId}/product/{productId}/order/place")
	public Order addOrder(@RequestBody Order newOrder, @PathVariable int customerId, @PathVariable int productId)
	{
		Customer customer = custRepo.getById(customerId);
		newOrder.setCustomer(customer);
		
		Product product = proRepo.getById(productId);
		newOrder.setProduct(product);
		
		Date date = new Date();
		newOrder.setOrderPlacedDt(date);
		Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, 2); 
        Date dateDispatch = cal.getTime();
        newOrder.setOrderDispatcherDt(dateDispatch);
        Calendar delivery = Calendar.getInstance();
        delivery.setTime(date);
        delivery.add(Calendar.DATE, 7); 
        Date dateDelivery = delivery.getTime();
        newOrder.setOrderDeliveredDt(dateDelivery);

		System.out.println("Here is your date of delivery : "+newOrder);
		Order order = ordRepo.save(newOrder);
		
		return order;
	}
	
}
