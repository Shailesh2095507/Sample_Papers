package com.cog.msc;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cog.msc.entity.Brand;
import com.cog.msc.entity.Customer;
import com.cog.msc.entity.Product;
import com.cog.msc.repository.BrandRepo;
import com.cog.msc.repository.CustomerRepo;
import com.cog.msc.repository.ProductRepo;

@SpringBootApplication
public class AsShoppingAppApplication implements CommandLineRunner
{

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	BrandRepo brandRepo;
	
	@Autowired
	ProductRepo productRepo;
	
	@Autowired
	CustomerRepo customerRepo; 
	
	public static void main(String[] args) 
	{
		SpringApplication.run(AsShoppingAppApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception 
	{
		// TODO Auto-generated method stub
		Brand brand1 = new Brand(1,"Levi's","YES");
		brandRepo.save(brand1);
		Brand brand2 = new Brand(2,"Kappa","NO");
		brandRepo.save(brand2);
		Brand brand3 = new Brand(3,"Umbro","YES");
		brandRepo.save(brand3);
		Brand brand4 = new Brand(4,"Adidas","YES");
		brandRepo.save(brand4);
		Brand brand5 = new Brand(5,"Boss","YES");
		brandRepo.save(brand5);
		
		Product product1 = new Product(21, "Levi's T-Shirt", 2999, 6, brandRepo.getById(1));
		productRepo.save(product1);
		Product product2 = new Product(22, "Levi's Denim", 4999, 3, brandRepo.getById(1));
		productRepo.save(product2);
		Product product3 = new Product(23, "Levi's Shirt", 3999, 5, brandRepo.getById(1));
		productRepo.save(product3);
		Product product4 = new Product(24, "Umbro Shoe", 3599, 6, brandRepo.getById(3));
		productRepo.save(product4);
		Product product5 = new Product(25, "Adidas Jacket", 5999, 3, brandRepo.getById(4));
		productRepo.save(product5);
		Product product6 = new Product(26, "Boss Denim", 7999, 8, brandRepo.getById(5));
		productRepo.save(product6);
		
		
		Customer customer1 = new Customer(31, "Sanjeev", "Sanjeev_123");
		customerRepo.save(customer1);
		Customer customer2 = new Customer(32, "Shailu", "Shailu_123");
		customerRepo.save(customer2);
		Customer customer3 = new Customer(33, "Sanju", "Sanju_123");
		customerRepo.save(customer3);
		
		logger.info("All brand -> {} ", brandRepo.findAll());
		
	}

}
