package com.cog.msc.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Entity
@Getter
@Setter
public class Brand 
{
	@Id
	private int brandId;
	
	private String brandName;
	private String brandAvailStatus;
	
	public Brand() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Brand(String brandName, String brandAvailStatus) {
		super();
		this.brandName = brandName;
		this.brandAvailStatus = brandAvailStatus;
	}

	public Brand(int brandId, String brandName, String brandAvailStatus) {
		super();
		this.brandId = brandId;
		this.brandName = brandName;
		this.brandAvailStatus = brandAvailStatus;
	}

	
	public int getBrandId() {
		return brandId;
	}

	public void setBrandId(int brandId) {
		this.brandId = brandId;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public String getBrandAvailStatus() {
		return brandAvailStatus;
	}

	public void setBrandAvailStatus(String brandAvailStatus) {
		this.brandAvailStatus = brandAvailStatus;
	}

	@Override
	public String toString() {
		return "Brand [brandId=" + brandId + ", brandName=" + brandName + ", brandAvailStatus=" + brandAvailStatus
				+ "]";
	}
	
}
