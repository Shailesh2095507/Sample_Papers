package com.cog.msc.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cog.msc.entity.Order;

public interface OrderRepo extends JpaRepository<Order, Integer>{

}
