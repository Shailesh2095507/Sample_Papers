package com.cog.msc.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cog.msc.entity.Brand;


public interface BrandRepo extends JpaRepository<Brand, Integer>
{

}
